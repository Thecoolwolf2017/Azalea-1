export function test(mc, message) {
  console.warn("hi");
  mc.world.sendMessage(message);
}