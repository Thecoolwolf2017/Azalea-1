export default function addPermissionCommands(commands) {
  // add !perm
  commands.addCommand("perm", {
    aliases: ["permission", "p"],
    admin: true,
    async onRun(msg, args, theme, response) {
      // if(!isAdmin(msg.sender)) return response("ERROR No admin!");
    }
  });
}