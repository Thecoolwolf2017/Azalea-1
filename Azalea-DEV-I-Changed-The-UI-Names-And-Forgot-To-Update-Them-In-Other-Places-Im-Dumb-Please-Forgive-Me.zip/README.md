# 🌺 Azalea 🌺

***NOTE: AZALEA IS STILL IN BETA AND SOME FEATURES MIGHT NOT WORK PROPERLY***

**Azalea is a very customizable addon for Minecraft Bedrock.**

Current features:
- Admin UI
- Tag commands
- Custom UIs
- Bind items to commands
- Player reports
- Moderation
- Server reviews
- Too lazy to finish this list lmfao

Made by TRASH#0093 on Discord (or TheLegendaryTrashcan#8485 on Revolt)

[Talk on the Discord server](https://discord.gg/azalea-1-year-anniversary-922867041029984316) or [talk on the Revolt server](https://rvlt.gg/PjgTYFgF)
