// here i store shit related to version data
// TODO: make this thing useles
export const VersionData = {}