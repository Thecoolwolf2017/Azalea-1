import { CommandBuilder } from '../commandBuilder';

export default function() {
    new CommandBuilder("floating-text")
        .desc("Float")
        .category("Fun")
        .requiresAdmin(true)
        .callback(({msg,args,theme,response})=>{
            let rabbit = msg.sender.dimension.spawnEntity("rabbit", msg.sender.location);
            rabbit.nameTag = args.join(' ').replaceAll('\\n','\n')
        })
        .register();
}