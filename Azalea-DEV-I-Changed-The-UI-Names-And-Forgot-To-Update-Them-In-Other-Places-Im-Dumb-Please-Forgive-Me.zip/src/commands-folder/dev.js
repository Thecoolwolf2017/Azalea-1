import { uiManager } from '../uis';

export default function addVersionCommand(commands) {
    commands.addCommand("testing", {
        description: "Command to test code",
        isDev: true,
        category: "Development",
        onRun(msg, args, theme, response) {
            response(`TEXT Text response`)
            response(`RESPONSE1 Miscellaneous response`);
            response(`INFO Info response`);
            response(`WARN Warn response`);
            response(`ERROR Error response`);
            response(`SUCCESS Success response`);
        }
    })
    commands.addCommand("chatdialog", {
        description: "Command to test code",
        isDev: true,
        category: "Development",
        onRun(msg, args, theme, response) {
            response(`TEXT ${theme.category}+---- ${theme.header}DIALOG ${theme.category}----+`);
            response(`TEXT ${theme.category}|                        |`);
            response(`TEXT ${theme.category}| §rThis is a test       ${theme.category}|`);
            response(`TEXT ${theme.category}|                        |`);
            response(`TEXT ${theme.category}+---------------+`)
        }
    })
    commands.addCommand("uis", {
        description: "View UIs through UI manager",
        isDev: true,
        category: "Development",
        onRun(msg,args, theme, response) {
            let uis = uiManager.uis.map(_=>_.id);
            let text = [`${theme.category}----- ${theme.header}UI IDs ${theme.category}-----`];
            for(const id of uis) {
                text.push(id);
            }
            response(`TEXT ${text.join('\n§r')}`)
        }
    })
}